@echo off
cd /d "%~dp0"

:: Check if pythonw is globally accessible in PATH
where pythonw >nul 2>nul
if %errorlevel% equ 0 (
    start "" pythonw "server.py"
    exit
)

:: Check for the user-specific Python Core folder (discovered on this system)
if exist "%USERPROFILE%\AppData\Local\Python\pythoncore-3.14-64\pythonw.exe" (
    start "" "%USERPROFILE%\AppData\Local\Python\pythoncore-3.14-64\pythonw.exe" "server.py"
    exit
)

:: Fallback to python.exe if pythonw isn't found (will show console, but runs successfully)
where python >nul 2>nul
if %errorlevel% equ 0 (
    start "" python "server.py"
    exit
)

echo =======================================================
echo ERROR: Python could not be found on your system!
echo =======================================================
echo Please verify Python is installed and added to PATH.
echo.
pause

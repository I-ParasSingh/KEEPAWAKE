let appState = {
    active: false,
    keep_screen_on: true,
    elapsed: 0,
    timeout_limit: null
};

// UI Elements
const powerBtn = document.getElementById('power-btn');
const statusBadge = document.getElementById('status-badge');
const timerDisplay = document.getElementById('timer-display');
const timerLabel = document.getElementById('timer-label');
const screenSwitch = document.getElementById('screen-switch');
const timeoutSelect = document.getElementById('timeout-select');
const logHeader = document.getElementById('log-header');
const logDrawer = document.getElementById('log-drawer');
const logContent = document.getElementById('log-content');

// Collapsible log drawer toggle
logHeader.addEventListener('click', () => {
    logDrawer.classList.toggle('open');
});

function logMsg(message, type = 'muted') {
    const timestamp = new Date().toLocaleTimeString();
    const line = document.createElement('div');
    line.className = `log-line ${type}`;
    line.innerText = `[${timestamp}] ${message}`;
    logContent.appendChild(line);
    logContent.scrollTop = logContent.scrollHeight;
    
    // Limit log lines
    while (logContent.children.length > 20) {
        logContent.removeChild(logContent.firstChild);
    }
}

// Format seconds into HH:MM:SS
function formatTime(seconds) {
    let hrs = Math.floor(seconds / 3600);
    let mins = Math.floor((seconds % 3600) / 60);
    let secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

// Update local UI from state
function updateUI() {
    if (appState.active) {
        powerBtn.classList.add('active');
        statusBadge.innerText = 'AWAKE';
        statusBadge.classList.add('active');
        timerDisplay.innerText = formatTime(appState.elapsed);
        timerLabel.innerText = 'Keep Awake Active';
    } else {
        powerBtn.classList.remove('active');
        statusBadge.innerText = 'STANDBY';
        statusBadge.classList.remove('active');
        timerDisplay.innerText = '00:00:00';
        timerLabel.innerText = 'Session Idle';
    }
    
    screenSwitch.checked = appState.keep_screen_on;
    if (appState.timeout_limit !== null) {
        timeoutSelect.value = appState.timeout_limit.toString();
    } else {
        timeoutSelect.value = "0";
    }
}

// Sync status from backend
async function syncStatus() {
    try {
        const res = await fetch('/api/status');
        if (res.ok) {
            const data = await res.json();
            
            // Log changes
            if (data.active !== appState.active) {
                logMsg(data.active ? 'Shield Engaged (Sleep Blocked)' : 'Shield Disengaged (Sleep Allowed)', 'sys');
            }
            
            appState = data;
            updateUI();
        }
    } catch (err) {
        // Suppress errors during disconnects
    }
}

// Send toggle commands to backend
async function sendToggle(activeState) {
    try {
        let timeoutVal = parseInt(timeoutSelect.value);
        let timeout = timeoutVal > 0 ? timeoutVal : null;
        
        const res = await fetch('/api/toggle', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                active: activeState,
                keep_screen_on: screenSwitch.checked,
                timeout: timeout
            })
        });
        
        if (res.ok) {
            const data = await res.json();
            appState = data;
            updateUI();
        }
    } catch (err) {
        logMsg('Connection error to server', 'err');
    }
}

// Heartbeat Loop (keeps python process alive) - Run less frequently to avoid background suspension
async function sendHeartbeat() {
    try {
        await fetch('/api/heartbeat', { method: 'POST' });
    } catch (err) {
        logMsg('Lost connection to backend engine', 'err');
    }
}

// Tick local clock display every second
function tickLocalTimer() {
    if (appState.active) {
        appState.elapsed++;
        timerDisplay.innerText = formatTime(appState.elapsed);
    }
}

// Event Listeners
powerBtn.addEventListener('click', () => {
    sendToggle(!appState.active);
});

screenSwitch.addEventListener('change', () => {
    sendToggle(appState.active);
});

timeoutSelect.addEventListener('change', () => {
    sendToggle(appState.active);
});

// React instantly when page returns from background
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        syncStatus();
    }
});

// Send synchronous shutdown beacon when browser tab or app window is closed
function handleShutdown() {
    navigator.sendBeacon('/api/shutdown');
}
window.addEventListener('beforeunload', handleShutdown);
window.addEventListener('pagehide', handleShutdown);

// Initializations
syncStatus();
setInterval(tickLocalTimer, 1000);  // Update clock UI every 1s
setInterval(sendHeartbeat, 15000);  // Heartbeat ping every 15s (safely survives browser throttling)
setInterval(syncStatus, 5000);      // Full status sync every 5s
logMsg('Portal connected to KeepAwake engine', 'sys');
logMsg('Ready to activate sleep blocking', 'muted');


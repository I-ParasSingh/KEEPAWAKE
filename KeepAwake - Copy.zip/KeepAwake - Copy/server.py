import sys
import os
import time
import ctypes
import webbrowser
import threading
import json
from http.server import HTTPServer, BaseHTTPRequestHandler

# Win32 API execution state constants
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

class SleepBlocker:
    def __init__(self):
        self.is_active = False
        self.keep_screen_on = True
        self.start_time = None
        self.last_heartbeat = time.time()
        self.timeout_limit = None  # in seconds
        
    def set_block(self, active, keep_screen_on=True):
        self.is_active = active
        self.keep_screen_on = keep_screen_on
        if active:
            if self.start_time is None:
                self.start_time = time.time()
            flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED
            if keep_screen_on:
                flags |= ES_DISPLAY_REQUIRED
            ctypes.windll.kernel32.SetThreadExecutionState(flags)
        else:
            self.start_time = None
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)

blocker = SleepBlocker()

class RequestHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress logging HTTP requests to console
        pass
        
    def do_GET(self):
        if self.path == '/':
            self.send_file('index.html', 'text/html')
        elif self.path == '/style.css':
            self.send_file('style.css', 'text/css')
        elif self.path == '/app.js':
            self.send_file('app.js', 'application/javascript')
        elif self.path == '/api/status':
            self.send_json(self.get_status_dict())
        else:
            self.send_error(404)
            
    def do_POST(self):
        if self.path == '/api/heartbeat':
            blocker.last_heartbeat = time.time()
            # Perform timeout check in backend
            if blocker.is_active and blocker.timeout_limit:
                elapsed = time.time() - blocker.start_time
                if elapsed >= blocker.timeout_limit:
                    blocker.set_block(False)
            self.send_json({"status": "ok"})
            
        elif self.path == '/api/toggle':
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            
            active = data.get('active', False)
            keep_screen_on = data.get('keep_screen_on', True)
            timeout = data.get('timeout', None)  # in seconds or None
            
            blocker.timeout_limit = timeout
            blocker.set_block(active, keep_screen_on)
            blocker.last_heartbeat = time.time()
            
            self.send_json(self.get_status_dict())
            
        elif self.path == '/api/shutdown':
            # Release sleep block and shut down server
            blocker.set_block(False)
            self.send_json({"status": "shutting_down"})
            # Launch delayed exit in a thread to allow response to flush
            threading.Thread(target=lambda: (time.sleep(0.5), os._exit(0)), daemon=True).start()
        else:
            self.send_error(404)
            
    def send_file(self, filename, content_type):
        try:
            script_dir = os.path.dirname(os.path.abspath(__file__))
            filepath = os.path.join(script_dir, filename)
            with open(filepath, 'rb') as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        except Exception:
            self.send_error(500)
            
    def send_json(self, data):
        content = json.dumps(data).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)
        
    def get_status_dict(self):
        elapsed = 0
        if blocker.is_active and blocker.start_time:
            elapsed = int(time.time() - blocker.start_time)
        return {
            "active": blocker.is_active,
            "keep_screen_on": blocker.keep_screen_on,
            "elapsed": elapsed,
            "timeout_limit": blocker.timeout_limit
        }

def monitor_heartbeat():
    while True:
        time.sleep(5)
        # If no heartbeat has been received for more than 90 seconds (survives minimized/tab-throttling), shut down
        if time.time() - blocker.last_heartbeat > 90.0:
            # Restore Windows defaults and exit
            blocker.set_block(False)
            os._exit(0)

def launch_browser():
    time.sleep(0.8)  # Wait for server to bind
    
    # Try Chrome or Edge App mode (forces standalone window with exact sizing)
    app_browsers = [
        # Chrome
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        # Edge
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"
    ]
    
    opened = False
    for path in app_browsers:
        if os.path.exists(path):
            try:
                import subprocess
                # Launch in App Mode with custom window size
                subprocess.Popen([path, "--app=http://127.0.0.1:5001", "--window-size=400,640"])
                opened = True
                break
            except Exception:
                pass
                
    if not opened:
        webbrowser.open('http://127.0.0.1:5001')


def main():
    # Start heartbeat monitor thread
    monitor_thread = threading.Thread(target=monitor_heartbeat, daemon=True)
    monitor_thread.start()
    
    # Start browser launcher thread
    browser_thread = threading.Thread(target=launch_browser, daemon=True)
    browser_thread.start()
    
    # Start HTTP server
    server_address = ('127.0.0.1', 5001)
    httpd = HTTPServer(server_address, RequestHandler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        blocker.set_block(False)

if __name__ == '__main__':
    main()

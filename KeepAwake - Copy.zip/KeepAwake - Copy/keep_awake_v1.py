import sys
import os
import time
import ctypes
import tkinter as tk
import winsound

# Win32 API execution state constants
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

class CustomCheckbutton(tk.Frame):
    """A highly-styled, modern alternative to standard Tkinter Checkbutton."""
    def __init__(self, parent, text, default=False, callback=None, bg="#1e293b", fg="#f8fafc"):
        super().__init__(parent, bg=bg)
        self.value = default
        self.callback = callback
        self.fg = fg
        self.bg = bg
        
        # Checkbox square label
        self.box_lbl = tk.Label(
            self, 
            text="✔" if self.value else " ", 
            font=("Segoe UI", 10, "bold"), 
            bg="#10b981" if self.value else "#475569", 
            fg="#ffffff" if self.value else "#94a3b8",
            width=3,
            height=1,
            relief="flat",
            bd=0,
            cursor="hand2"
        )
        self.box_lbl.pack(side="left", padx=(0, 10))
        
        # Text description label
        self.text_lbl = tk.Label(
            self, 
            text=text, 
            font=("Segoe UI", 10), 
            bg=bg, 
            fg=fg,
            cursor="hand2"
        )
        self.text_lbl.pack(side="left")
        
        # Bind click events
        self.box_lbl.bind("<Button-1>", self.toggle)
        self.text_lbl.bind("<Button-1>", self.toggle)
        self.bind("<Button-1>", self.toggle)
        
        # Hover events
        self.box_lbl.bind("<Enter>", lambda e: self.on_enter())
        self.box_lbl.bind("<Leave>", lambda e: self.on_leave())
        self.text_lbl.bind("<Enter>", lambda e: self.on_enter())
        self.text_lbl.bind("<Leave>", lambda e: self.on_leave())
        
    def toggle(self, event=None):
        self.value = not self.value
        self.update_appearance()
        if self.callback:
            self.callback(self.value)
            
    def update_appearance(self):
        if self.value:
            self.box_lbl.config(text="✔", bg="#10b981", fg="#ffffff")
        else:
            self.box_lbl.config(text=" ", bg="#475569", fg="#94a3b8")
            
    def on_enter(self):
        if not self.value:
            self.box_lbl.config(bg="#64748b")
            
    def on_leave(self):
        if not self.value:
            self.box_lbl.config(bg="#475569")
            
    def get(self):
        return self.value
        
    def set(self, value):
        self.value = bool(value)
        self.update_appearance()


class StayAwakeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("StayAwake")
        self.root.resizable(False, False)
        
        # UI State Variables
        self.is_active = False
        self.start_time = None
        
        # Styling Palette
        self.bg_main = "#0f172a"      # slate-900
        self.bg_card = "#1e293b"      # slate-800
        self.color_active = "#10b981"  # emerald-500
        self.color_inactive = "#475569"# slate-600
        self.color_alert = "#ef4444"   # red-500
        self.text_main = "#f8fafc"     # slate-50
        self.text_muted = "#94a3b8"    # slate-400
        
        # Apply Main Window Configuration
        self.root.config(bg=self.bg_main)
        self.center_window(360, 440)
        
        # Build UI Elements
        self.create_widgets()
        
        # Listen for closing window to cleanly release OS block
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Initial status update
        self.update_status_ui()
        
    def center_window(self, width, height):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        
    def create_widgets(self):
        # 1. Header Frame
        header = tk.Frame(self.root, bg=self.bg_main, pady=15)
        header.pack(fill="x")
        
        title_lbl = tk.Label(
            header, 
            text="StayAwake", 
            font=("Segoe UI", 18, "bold"), 
            bg=self.bg_main, 
            fg=self.text_main
        )
        title_lbl.pack()
        
        subtitle_lbl = tk.Label(
            header, 
            text="System sleep prevention utility", 
            font=("Segoe UI", 9), 
            bg=self.bg_main, 
            fg=self.text_muted
        )
        subtitle_lbl.pack()
        
        # 2. Glowing Status Indicator (Canvas)
        self.status_canvas = tk.Canvas(
            self.root, 
            width=90, 
            height=90, 
            bg=self.bg_main, 
            highlightthickness=0
        )
        self.status_canvas.pack(pady=(0, 10))
        
        # Draw status ring and core
        self.outer_ring = self.status_canvas.create_oval(
            15, 15, 75, 75, 
            outline=self.color_inactive, 
            width=4
        )
        self.inner_core = self.status_canvas.create_oval(
            30, 30, 60, 60, 
            fill=self.color_inactive, 
            outline=""
        )
        
        # Status descriptive label
        self.status_lbl = tk.Label(
            self.root, 
            text="SYSTEM SLEEP ALLOWED", 
            font=("Segoe UI", 10, "bold"), 
            bg=self.bg_main, 
            fg=self.text_muted
        )
        self.status_lbl.pack()
        
        # Timer Label (displays active time duration)
        self.timer_lbl = tk.Label(
            self.root, 
            text="Elapsed: --:--:--", 
            font=("Consolas", 11), 
            bg=self.bg_main, 
            fg=self.text_muted
        )
        self.timer_lbl.pack(pady=(5, 10))
        
        # 3. Main Toggle Button
        self.toggle_btn = tk.Button(
            self.root, 
            text="ACTIVATE", 
            font=("Segoe UI", 12, "bold"), 
            bg=self.color_active, 
            fg="#ffffff", 
            activebackground="#059669", 
            activeforeground="#ffffff", 
            relief="flat", 
            bd=0, 
            padx=30, 
            pady=10, 
            cursor="hand2",
            command=self.toggle_awake_state
        )
        self.toggle_btn.pack(pady=10)
        self.toggle_btn.bind("<Enter>", lambda e: self.on_button_hover(True))
        self.toggle_btn.bind("<Leave>", lambda e: self.on_button_hover(False))
        
        # 4. Settings Card (Grouped controls)
        settings_frame = tk.Frame(
            self.root, 
            bg=self.bg_card, 
            padx=20, 
            pady=15, 
            relief="flat", 
            bd=0
        )
        settings_frame.pack(fill="x", padx=25, pady=(15, 0))
        
        # Keep Screen On checkbox
        self.screen_chk = CustomCheckbutton(
            settings_frame, 
            text="Keep screen turned on", 
            default=True,
            callback=self.on_screen_option_changed,
            bg=self.bg_card,
            fg=self.text_main
        )
        self.screen_chk.pack(anchor="w", pady=(0, 10))
        
        # Always on Top checkbox
        self.topmost_chk = CustomCheckbutton(
            settings_frame, 
            text="Keep window on top", 
            default=False,
            callback=self.on_topmost_changed,
            bg=self.bg_card,
            fg=self.text_main
        )
        self.topmost_chk.pack(anchor="w", pady=(0, 12))
        
        # Auto-disable dropdown row
        dropdown_row = tk.Frame(settings_frame, bg=self.bg_card)
        dropdown_row.pack(fill="x")
        
        drop_lbl = tk.Label(
            dropdown_row, 
            text="Auto-Disable after:", 
            font=("Segoe UI", 10), 
            bg=self.bg_card, 
            fg=self.text_muted
        )
        drop_lbl.pack(side="left")
        
        self.timer_var = tk.StringVar(self.root)
        self.timer_var.set("Never")
        timer_options = ["Never", "15 Minutes", "30 Minutes", "1 Hour", "2 Hours", "4 Hours", "8 Hours"]
        
        self.opt_menu = tk.OptionMenu(
            dropdown_row, 
            self.timer_var, 
            *timer_options,
            command=self.on_timeout_changed
        )
        self.opt_menu.config(
            bg=self.bg_main, 
            fg=self.text_main, 
            activebackground=self.bg_card, 
            activeforeground=self.text_main, 
            relief="flat", 
            bd=0, 
            highlightthickness=0,
            font=("Segoe UI", 9),
            cursor="hand2"
        )
        self.opt_menu["menu"].config(
            bg=self.bg_card, 
            fg=self.text_main, 
            activebackground=self.color_active, 
            activeforeground="#ffffff", 
            relief="flat", 
            bd=0
        )
        self.opt_menu.pack(side="right")
        
    def on_button_hover(self, is_hover):
        if is_hover:
            if self.is_active:
                self.toggle_btn.config(bg="#dc2626")  # Darker red
            else:
                self.toggle_btn.config(bg="#059669")  # Darker green
        else:
            if self.is_active:
                self.toggle_btn.config(bg=self.color_alert)
            else:
                self.toggle_btn.config(bg=self.color_active)
                
    def on_screen_option_changed(self, value):
        # If already active, immediately adjust the thread execution flags to apply changes
        if self.is_active:
            self.set_windows_sleep_block(active=True, keep_screen_on=value)
            
    def on_topmost_changed(self, value):
        self.root.attributes("-topmost", value)
        
    def on_timeout_changed(self, value):
        # Just outputs state, loop checks this value reactively
        pass
        
    def set_windows_sleep_block(self, active=True, keep_screen_on=True):
        """Calls win32 API SetThreadExecutionState to prevent system sleep."""
        if active:
            flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED
            if keep_screen_on:
                flags |= ES_DISPLAY_REQUIRED
            ctypes.windll.kernel32.SetThreadExecutionState(flags)
        else:
            # Revert to OS default (just continuous flag with no requirements)
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            
    def toggle_awake_state(self):
        self.is_active = not self.is_active
        if self.is_active:
            self.start_time = time.time()
            self.set_windows_sleep_block(active=True, keep_screen_on=self.screen_chk.get())
            # Start timer loop
            self.update_timer_loop()
        else:
            self.start_time = None
            self.set_windows_sleep_block(active=False)
            
        self.update_status_ui()
        
    def update_status_ui(self):
        if self.is_active:
            # Active glowing style
            self.status_canvas.itemconfig(self.outer_ring, outline=self.color_active)
            self.status_canvas.itemconfig(self.inner_core, fill=self.color_active)
            self.status_lbl.config(text="PREVENTING SYSTEM SLEEP", fg=self.color_active)
            self.toggle_btn.config(text="DEACTIVATE", bg=self.color_alert)
        else:
            # Inactive sleep allowed style
            self.status_canvas.itemconfig(self.outer_ring, outline=self.color_inactive)
            self.status_canvas.itemconfig(self.inner_core, fill=self.color_inactive)
            self.status_lbl.config(text="SYSTEM SLEEP ALLOWED", fg=self.text_muted)
            self.timer_lbl.config(text="Elapsed: --:--:--")
            self.toggle_btn.config(text="ACTIVATE", bg=self.color_active)
            
    def get_limit_seconds(self):
        option = self.timer_var.get()
        if "Minute" in option:
            val = int(option.split()[0])
            return val * 60
        elif "Hour" in option:
            val = int(option.split()[0])
            return val * 3600
        return None # "Never"
        
    def update_timer_loop(self):
        if not self.is_active or self.start_time is None:
            return
            
        elapsed = int(time.time() - self.start_time)
        
        # Format and update display
        hours = elapsed // 3600
        minutes = (elapsed % 3600) // 60
        seconds = elapsed % 60
        self.timer_lbl.config(text=f"Elapsed: {hours:02d}:{minutes:02d}:{seconds:02d}")
        
        # Check auto-disable criteria
        limit = self.get_limit_seconds()
        if limit is not None and elapsed >= limit:
            self.toggle_awake_state()
            # Alert user via standard windows beep
            try:
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            except Exception:
                pass
            return
            
        # Run again in 1 second
        self.root.after(1000, self.update_timer_loop)
        
    def on_closing(self):
        # Always restore default Windows power management behaviors on exit
        self.set_windows_sleep_block(active=False)
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = StayAwakeApp(root)
    root.mainloop()

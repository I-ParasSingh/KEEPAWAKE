import sys
import os
import time
import ctypes
import tkinter as tk
import winsound
import random
from math import cos, sin, pi

# Win32 API execution state constants
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

class CyberSwitch(tk.Frame):
    """A cool, console-styled toggle switch for the cyberpunk HUD."""
    def __init__(self, parent, text, default=False, callback=None, bg="#0d131f", fg_active="#00ff66", fg_inactive="#ff0055"):
        super().__init__(parent, bg=bg)
        self.value = default
        self.callback = callback
        self.bg = bg
        self.fg_active = fg_active
        self.fg_inactive = fg_inactive
        
        # Switch text description
        self.text_lbl = tk.Label(
            self, 
            text=text, 
            font=("Consolas", 10), 
            bg=bg, 
            fg="#00ffcc",
            anchor="w"
        )
        self.text_lbl.pack(side="left", fill="x", expand=True)
        
        # Indicator switch label
        self.switch_lbl = tk.Label(
            self, 
            text="[ ACTIVE ]" if self.value else "[ LOCKED ]", 
            font=("Consolas", 9, "bold"), 
            bg=bg, 
            fg=self.fg_active if self.value else self.fg_inactive,
            width=12,
            relief="solid",
            bd=1,
            cursor="hand2"
        )
        self.switch_lbl.pack(side="right", padx=(10, 0))
        
        # Bind click events
        self.switch_lbl.bind("<Button-1>", self.toggle)
        self.text_lbl.bind("<Button-1>", self.toggle)
        
        # Hover events
        self.switch_lbl.bind("<Enter>", lambda e: self.on_enter())
        self.switch_lbl.bind("<Leave>", lambda e: self.on_leave())
        
    def toggle(self, event=None):
        self.value = not self.value
        self.update_appearance()
        if self.callback:
            self.callback(self.value)
            
    def update_appearance(self):
        if self.value:
            self.switch_lbl.config(
                text="[ ACTIVE ]", 
                fg=self.fg_active
            )
        else:
            self.switch_lbl.config(
                text="[ LOCKED ]", 
                fg=self.fg_inactive
            )
            
    def on_enter(self):
        self.switch_lbl.config(bg="#1a2333")
        
    def on_leave(self):
        self.switch_lbl.config(bg=self.bg)
            
    def get(self):
        return self.value
        
    def set(self, value):
        self.value = bool(value)
        self.update_appearance()


class StayAwakeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("// SYSTEM_INSOMNIA_v1.0")
        self.root.resizable(False, False)
        
        # UI State Variables
        self.is_active = False
        self.start_time = None
        self.radar_angle = 0.0
        self.radar_sweep_speed = 0.07  # Radians per frame
        self.radar_update_ms = 40       # ~25 FPS
        self.radar_line = None
        
        # High-Contrast Cyberpunk Palette
        self.bg_main = "#05070a"        # Void black-blue
        self.bg_card = "#0d131f"        # Dark metallic card
        self.border_color = "#00f0ff"   # Neon Cyan
        self.text_color = "#00ffcc"     # Electric green-cyan
        self.text_muted = "#3a537d"     # Cyber slate blue
        self.color_active = "#00ff66"   # Matrix Green
        self.color_inactive = "#223554" # Dull tech blue
        self.color_alert = "#ff0055"    # Neon Magenta/Red
        
        # Configure Main Window
        self.root.config(bg=self.bg_main)
        self.center_window(380, 540)
        
        # Build UI Elements
        self.create_widgets()
        
        # Register standard shutdown protocol
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Initial status setup
        self.update_status_ui()
        self.log_msg("SHIELD_SYS_BOOT: v1.0.2")
        self.log_msg("KERNEL_LINK: ESTABLISHED")
        self.log_msg("SLEEP_INHIBITOR: STANDBY")
        
    def center_window(self, width, height):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - width) // 2
        y = (screen_height - height) // 2
        self.root.geometry(f"{width}x{height}+{x}+{y}")
        
    def create_widgets(self):
        # 1. Title/Header Frame
        header = tk.Frame(self.root, bg=self.bg_main, pady=10)
        header.pack(fill="x")
        
        title_lbl = tk.Label(
            header, 
            text="// INSOMNIA_SYSTEM_v1.0", 
            font=("Consolas", 14, "bold"), 
            bg=self.bg_main, 
            fg=self.border_color
        )
        title_lbl.pack()
        
        # Thin divider line
        divider = tk.Frame(self.root, bg=self.text_muted, height=1)
        divider.pack(fill="x", padx=25, pady=(0, 10))
        
        # 2. Glowing Canvas for Radar/HUD Animation
        self.status_canvas = tk.Canvas(
            self.root, 
            width=120, 
            height=120, 
            bg=self.bg_main, 
            highlightthickness=0
        )
        self.status_canvas.pack(pady=5)
        self.draw_hud()
        
        # HUD Status text label
        self.status_lbl = tk.Label(
            self.root, 
            text="[ SHIELD: STANDBY ]", 
            font=("Consolas", 11, "bold"), 
            bg=self.bg_main, 
            fg=self.text_muted
        )
        self.status_lbl.pack()
        
        # Timer Label
        self.timer_lbl = tk.Label(
            self.root, 
            text="SYS_TIME_ELAPSED: --:--:--", 
            font=("Consolas", 10), 
            bg=self.bg_main, 
            fg=self.text_muted
        )
        self.timer_lbl.pack(pady=(2, 8))
        
        # 3. Main Toggle Button (Interactive HUD button)
        self.toggle_btn = tk.Button(
            self.root, 
            text="[ ENGAGE SHIELD ]", 
            font=("Consolas", 12, "bold"), 
            bg=self.bg_main, 
            fg=self.border_color, 
            activebackground=self.bg_card, 
            activeforeground=self.text_color, 
            relief="solid", 
            bd=1, 
            highlightthickness=0,
            padx=20, 
            pady=8, 
            cursor="hand2",
            command=self.toggle_awake_state
        )
        self.toggle_btn.pack(pady=10)
        self.toggle_btn.bind("<Enter>", lambda e: self.on_button_hover(True))
        self.toggle_btn.bind("<Leave>", lambda e: self.on_button_hover(False))
        
        # 4. Settings Card Frame (Metallic console style border)
        settings_frame = tk.Frame(
            self.root, 
            bg=self.bg_card, 
            padx=15, 
            pady=15, 
            relief="solid", 
            bd=1,
            highlightbackground=self.text_muted,
            highlightthickness=0
        )
        settings_frame.pack(fill="x", padx=25, pady=(10, 0))
        
        # Screen Checkbox
        self.screen_chk = CyberSwitch(
            settings_frame, 
            text="SCREEN_KEEP_ALIVE", 
            default=True,
            callback=self.on_screen_option_changed,
            bg=self.bg_card
        )
        self.screen_chk.pack(fill="x", pady=(0, 8))
        
        # Window topmost Checkbox
        self.topmost_chk = CyberSwitch(
            settings_frame, 
            text="HUD_ALWAYS_ON_TOP", 
            default=False,
            callback=self.on_topmost_changed,
            bg=self.bg_card
        )
        self.topmost_chk.pack(fill="x", pady=(0, 10))
        
        # Dropdown Auto Timeout
        dropdown_row = tk.Frame(settings_frame, bg=self.bg_card)
        dropdown_row.pack(fill="x")
        
        drop_lbl = tk.Label(
            dropdown_row, 
            text="SHIELD_TIMEOUT:", 
            font=("Consolas", 10), 
            bg=self.bg_card, 
            fg=self.text_muted
        )
        drop_lbl.pack(side="left")
        
        self.timer_var = tk.StringVar(self.root)
        self.timer_var.set("Never")
        timer_options = ["Never", "15 Minutes", "30 Minutes", "1 Hour", "2 Hours", "4 Hours", "8 Hours"]
        
        self.opt_menu = tk.OptionMenu(
            dropdown_row, 
            self.timer_var, 
            *timer_options,
            command=self.on_timeout_changed
        )
        self.opt_menu.config(
            bg=self.bg_main, 
            fg=self.text_color, 
            activebackground=self.bg_card, 
            activeforeground=self.text_color, 
            relief="solid", 
            bd=1, 
            highlightthickness=0,
            font=("Consolas", 9),
            cursor="hand2"
        )
        self.opt_menu["menu"].config(
            bg=self.bg_card, 
            fg=self.text_color, 
            activebackground=self.border_color, 
            activeforeground=self.bg_main, 
            relief="solid", 
            bd=1
        )
        self.opt_menu.pack(side="right")
        
        # 5. Diagnostic Console Stream Log (Bottom Card)
        log_frame = tk.Frame(
            self.root, 
            bg=self.bg_main, 
            highlightbackground=self.text_muted, 
            highlightthickness=1, 
            bd=0
        )
        log_frame.pack(fill="both", expand=True, padx=25, pady=(15, 15))
        
        log_title = tk.Label(
            log_frame, 
            text=" // DIAGNOSTIC_LOG_STREAM", 
            font=("Consolas", 8, "bold"), 
            bg=self.text_muted, 
            fg=self.bg_main, 
            anchor="w"
        )
        log_title.pack(fill="x")
        
        self.log_text = tk.Text(
            log_frame, 
            bg=self.bg_main, 
            fg=self.text_color, 
            font=("Consolas", 9), 
            bd=0, 
            highlightthickness=0, 
            height=4, 
            width=35,
            state="disabled"
        )
        self.log_text.pack(padx=8, pady=4, fill="both", expand=True)
        
    def draw_hud(self):
        cx, cy = 60, 60
        
        # Faint Tech Crosshairs
        self.status_canvas.create_line(15, cy, 105, cy, fill="#121b2d", dash=(2, 2))
        self.status_canvas.create_line(cx, 15, cx, 105, fill="#121b2d", dash=(2, 2))
        
        # Concentric Radar rings
        self.status_canvas.create_oval(cx-15, cy-15, cx+15, cy+15, outline=self.color_inactive, width=1, tags="hud_active")
        self.status_canvas.create_oval(cx-32, cy-32, cx+32, cy+32, outline=self.color_inactive, width=1, tags="hud_active")
        
        # Center glowing core dot
        self.status_canvas.create_oval(cx-4, cy-4, cx+4, cy+4, fill=self.color_inactive, outline="", tags="hud_active_fill")
        
        # Octagon HUD shell
        oct_points = []
        for i in range(8):
            a = i * (pi / 4)
            oct_points.append(cx + 48 * cos(a))
            oct_points.append(cy + 48 * sin(a))
        self.status_canvas.create_polygon(oct_points, fill="", outline=self.color_inactive, width=1.5, tags="hud_active")
        
    def on_button_hover(self, is_hover):
        if is_hover:
            if self.is_active:
                self.toggle_btn.config(bg=self.color_alert, fg=self.bg_main)
            else:
                self.toggle_btn.config(bg=self.border_color, fg=self.bg_main)
        else:
            if self.is_active:
                self.toggle_btn.config(bg=self.color_alert, fg=self.bg_main)
            else:
                self.toggle_btn.config(bg=self.bg_main, fg=self.border_color)
                
    def on_screen_option_changed(self, value):
        self.log_msg(f"SCREEN_BLOCK: {'ENABLED' if value else 'BYPASSED'}")
        if self.is_active:
            self.set_windows_sleep_block(active=True, keep_screen_on=value)
            
    def on_topmost_changed(self, value):
        self.root.attributes("-topmost", value)
        self.log_msg(f"HUD_TOPMOST: {'ENGAGED' if value else 'RELEASED'}")
        
    def on_timeout_changed(self, value):
        self.log_msg(f"TIMEOUT_LIMIT_SET: {value.upper()}")
        
    def log_msg(self, message):
        self.log_text.config(state="normal")
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{timestamp}] {message}\n")
        self.log_text.see("end")
        
        # Truncate old terminal logs to save resources
        lines = int(self.log_text.index("end-1c").split(".")[0])
        if lines > 30:
            self.log_text.delete("1.0", "2.0")
            
        self.log_text.config(state="disabled")
        
    def set_windows_sleep_block(self, active=True, keep_screen_on=True):
        if active:
            flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED
            if keep_screen_on:
                flags |= ES_DISPLAY_REQUIRED
            ctypes.windll.kernel32.SetThreadExecutionState(flags)
        else:
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            
    def toggle_awake_state(self):
        self.is_active = not self.is_active
        if self.is_active:
            self.start_time = time.time()
            self.set_windows_sleep_block(active=True, keep_screen_on=self.screen_chk.get())
            self.log_msg("STATE: ACTIVE (PREVENTING SLEEP)")
            
            # Start loop operations
            self.update_timer_loop()
            self.update_radar()
            
            # Action Audio feedback (high beep upward)
            try:
                winsound.Beep(1200, 80)
                winsound.Beep(1600, 100)
            except Exception:
                pass
        else:
            self.start_time = None
            self.set_windows_sleep_block(active=False)
            self.log_msg("STATE: IDLE (SLEEP PERMITTED)")
            
            # Action Audio feedback (low beep downward)
            try:
                winsound.Beep(1600, 80)
                winsound.Beep(1200, 100)
            except Exception:
                pass
                
        self.update_status_ui()
        
    def update_status_ui(self):
        if self.is_active:
            # Active styling (neon green theme elements)
            self.status_canvas.itemconfig("hud_active", outline=self.color_active)
            self.status_canvas.itemconfig("hud_active_fill", fill=self.color_active)
            self.status_lbl.config(text="[ SHIELD: ACTIVE ]", fg=self.color_active)
            self.toggle_btn.config(
                text="[ DISENGAGE SHIELD ]", 
                bg=self.color_alert, 
                fg=self.bg_main
            )
        else:
            # Inactive styling (neutral blue-slate elements)
            self.status_canvas.itemconfig("hud_active", outline=self.color_inactive)
            self.status_canvas.itemconfig("hud_active_fill", fill=self.color_inactive)
            self.status_lbl.config(text="[ SHIELD: STANDBY ]", fg=self.text_muted)
            self.timer_lbl.config(text="SYS_TIME_ELAPSED: --:--:--")
            self.toggle_btn.config(
                text="[ ENGAGE SHIELD ]", 
                bg=self.bg_main, 
                fg=self.border_color
            )
            
    def get_limit_seconds(self):
        option = self.timer_var.get()
        if "Minute" in option:
            val = int(option.split()[0])
            return val * 60
        elif "Hour" in option:
            val = int(option.split()[0])
            return val * 3600
        return None
        
    def update_radar(self):
        if not self.is_active:
            if self.radar_line:
                self.status_canvas.delete(self.radar_line)
                self.radar_line = None
            return
            
        self.radar_angle = (self.radar_angle + self.radar_sweep_speed) % (2 * pi)
        
        cx, cy = 60, 60
        r = 45
        x2 = cx + r * cos(self.radar_angle)
        y2 = cy + r * sin(self.radar_angle)
        
        if self.radar_line:
            self.status_canvas.coords(self.radar_line, cx, cy, x2, y2)
        else:
            self.radar_line = self.status_canvas.create_line(
                cx, cy, x2, y2, 
                fill=self.color_active, 
                width=1.5,
                arrow="last"
            )
            
        self.root.after(self.radar_update_ms, self.update_radar)
        
    def update_timer_loop(self):
        if not self.is_active or self.start_time is None:
            return
            
        elapsed = int(time.time() - self.start_time)
        
        hours = elapsed // 3600
        minutes = (elapsed % 3600) // 60
        seconds = elapsed % 60
        self.timer_lbl.config(text=f"SYS_TIME_ELAPSED: {hours:02d}:{minutes:02d}:{seconds:02d}")
        
        # Periodic terminal logging
        if elapsed > 0 and elapsed % 10 == 0:
            heartbeats = [
                "HEARTBEAT: BLOCK_CONFIRMED",
                "SYS_PING: KERNEL_HOLD_OK",
                "SYS_FLOW: BYPASS_ACTIVE",
                "THREAD_LOG: THREAD_HEARTBEAT_OK"
            ]
            self.log_msg(random.choice(heartbeats))
            
        # Check auto-disable limit
        limit = self.get_limit_seconds()
        if limit is not None and elapsed >= limit:
            self.log_msg("AUTO_TIMEOUT: LIMIT EXCEEDED")
            self.toggle_awake_state()
            
            # Sound alarm pattern
            try:
                for _ in range(3):
                    winsound.Beep(1000, 150)
                    time.sleep(0.1)
            except Exception:
                pass
            return
            
        self.root.after(1000, self.update_timer_loop)
        
    def on_closing(self):
        self.set_windows_sleep_block(active=False)
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = StayAwakeApp(root)
    root.mainloop()
